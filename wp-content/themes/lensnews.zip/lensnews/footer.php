<?php global $salong; ?>
<!--网站页脚上的广告-->
<?php if($salong[ 'footer_code'] && !wp_is_mobile()) { ?>
<section class="footer_code wrapper">
    <?php echo $salong[ 'footer_code']; ?>
</section>
<?php } ?>
<footer class="footer">
    <!-- 版权 -->
    <section class="copyright">
        <p>
            <?php echo $salong[ 'copyright_text']; ?>
        </p>
        <?php if (get_option( 'zh_cn_l10n_icp_num' )){ ?>&nbsp;
        <?php echo get_option( 'zh_cn_l10n_icp_num' ); ?>
        <?php } ?>
        <?php if (class_exists( 'GoogleSitemapGeneratorLoader' )){ ?>&nbsp;
        <a href="<?php echo get_home_url(); ?>/sitemap.xml">
            <?php _e( '网站地图', 'salong' ); ?>
        </a>
        <?php } ?>
    </section>
    <section class="salongtheme">
       <?php echo $salong[ 'salongtheme_text']; ?>
        <?php if($salong[ 'tracking_code'] && !current_user_can('level_10')){ echo '&nbsp;<span>'.stripslashes($salong[ 'tracking_code']). '</span>'; } ?>
    </section>
    <!-- 版权end -->
    <!-- 侧边按钮 -->
    <?php get_template_part( 'content/footer', 'popup'); ?>
</footer>
<!--禁止复制-->
<?php if($salong['switch_copy']){ ?>
<script type="text/Javascript">
    document.oncontextmenu=function(e){return false;}; document.onselectstart=function(e){return false;};
</script>
<style>
    body {-moz-user-select: none;}
</style>
<SCRIPT LANGUAGE=javascript>
    if (top.location != self.location) top.location = self.location;
</SCRIPT>
<noscript>
    <iframe src=*.Html></iframe>
</noscript>
<?php } ?>
<?php if(wp_is_mobile()){echo '</section>';} ?>
<?php wp_footer(); ?>
<?php if ( !is_user_logged_in()) { get_template_part( 'content/front', 'login'); } ?>
<?php if(is_home() || is_singular() || is_archive() || is_search() || is_page_template( 'template-blog.php' ) || is_page_template( 'template-gallery.php' ) || is_page_template( 'template-video.php' )){if($salong[ 'switch_loadmore']){ get_template_part( 'includes/loadmore');}}?>
</body>

</html>