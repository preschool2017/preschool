<?php
/*
* Template Name: 完善资料
*/ 
get_header(); ?>
<!-- 主体内容 -->
<section class="container wpuf update">
    <!-- 内容 -->
    <!-- 获取文章 -->
    <article class="entry box<?php triangle();wow(); ?>">
       <h2><?php the_title(); ?></h2>
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <div class="content-post">
            <?php the_content(); ?>
        </div>
        <!-- 文章end -->
        <?php endwhile; endif; ?>
        <!-- 获取文章end -->
    </article>
    <!-- 内容end -->
</section>
<!-- 主体内容end -->
<?php get_footer(); ?>