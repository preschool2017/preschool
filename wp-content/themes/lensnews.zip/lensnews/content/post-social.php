<?php global $salong;
if (function_exists( 'wpfp_link_info')) {
?>
<section class="post-social">
    <!--文章点赞-->
    <div class="post-like">
        <?php echo getPostLikeLink(get_the_ID());?>
    </div>
    <!--打赏-->
    <div class="rewards">

        <a class="btn" href="#pay" title="<?php printf( __( '觉得%s有用请给作者打赏！' , 'salong' ), esc_attr(post_name())); ?>">
            <?php _e( '赏', 'salong'); ?>
        </a>
    </div>
    <div class="favorite">
        <?php wpfp_link(); ?>
    </div>
</section>
<?php } ?>