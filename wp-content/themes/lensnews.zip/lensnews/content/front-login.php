<!--前台弹窗登录-->
<a href="#ln" class="overlay" id="login"></a>
<section class="front_login popup">
    <section class="login_header">
        <h3><?php _e('用户登录','salong'); ?></h3>
        <a href="#ln" title="<?php _e('关闭','salong'); ?>"><i class="icon-cancel-circled"></i></a>
    </section>
    <?php if(class_exists( 'WPUF_Coupons' )) { ?>
    <div class="login" id="wpuf-login-form">

        <?php $message=apply_filters( 'login_message', '' ); if ( ! empty( $message ) ) { echo $message . "\n"; } ?>

        <?php WPUF_Login::init()->show_errors(); ?>
        <?php WPUF_Login::init()->show_messages(); ?>

        <form name="loginform" class="wpuf-login-form" id="loginform" action="<?php echo $action_url; ?>" method="post">
            <p>
                <label for="wpuf-user_login">
                    <?php _e( 'Username', 'wpuf' ); ?>
                </label>
                <input type="text" name="log" id="wpuf-user_login" class="input" value="" size="20" />
            </p>
            <p>
                <label for="wpuf-user_pass">
                    <?php _e( 'Password', 'wpuf' ); ?>
                </label>
                <input type="password" name="pwd" id="wpuf-user_pass" class="input" value="" size="20" />
            </p>

            <?php do_action( 'login_form' ); ?>

            <p class="forgetmenot">
                <input name="rememberme" type="checkbox" id="wpuf-rememberme" value="forever" />
                <label for="wpuf-rememberme">
                    <?php esc_attr_e( 'Remember Me' ); ?>
                </label>
            </p>

            <p class="login-submit">
                <input type="submit" name="wp-submit" id="wp-submit" class="button-primary" value="<?php esc_attr_e( 'Log In' ); ?>" />
                <input type="hidden" name="redirect_to" value="<?php echo WPUF_Login::get_posted_value( 'redirect_to' ); ?>" />
                <input type="hidden" name="wpuf_login" value="true" />
                <input type="hidden" name="action" value="login" />
                <?php wp_nonce_field( 'wpuf_login_action' ); ?>
            </p>
        </form>
    </div>
    <?php }else{ ?>
    <?php $args = array(
    'echo'           => true,
    'redirect'       => ( is_ssl() ? 'https://' : 'http://' ) . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'],
    'form_id'        => 'loginform',
    'label_username' => __( 'Username' ),
    'label_password' => __( 'Password' ),
    'label_remember' => __( 'Remember Me' ),
    'label_log_in'   => __( 'Log In' ),
    'id_username'    => 'user_login',
    'id_password'    => 'user_pass',
    'id_remember'    => 'rememberme',
    'id_submit'      => 'wp-submit',
    'remember'       => true,
    'value_username' => NULL,
    'value_remember' => true ); ?>
    <?php wp_login_form( $args ); ?>
    <?php } ?>
    <?php global $salong; if($salong[ 'switch_social_login']){ ?>
    <section class="social_login">
       <!--QQ登录-->
       <?php if($salong[ 'qqlogin_link']){ ?>
        <a href="<?php echo $salong['qqlogin_link']; ?>" class="qq" rel="nofollow"><span><?php _e('QQ帐号登录','salong'); ?></span><i class="icon-qq"></i></a>
       <!--新浪微博登录-->
        <?php } if($salong[ 'switch_weibo_login']){ ?>
        <a href="<?php echo weibo_oauth_url(); ?>" class="weibo" rel="nofollow"><span><?php _e('新浪微博登录','salong'); ?></span><i class="icon-weibo"></i></a>
       <!--微信登录-->
        <?php } if(salong_is_weixin() && $salong['wechatinnerlogin_link']){ ?>
        <a href="<?php echo $salong['wechatinnerlogin_link']; ?>" class="wechat" rel="nofollow"><span><?php _e('微信登录','salong'); ?></span><i class="icon-wechat"></i></a>
        <?php }else if($salong[ 'wechatlogin_link']){ ?>
        <a href="<?php echo $salong['wechatlogin_link']; ?>" class="wechat" rel="nofollow"><span><?php _e('微信登录','salong'); ?></span><i class="icon-wechat"></i></a>
        <?php } ?>
    </section>
    <?php } ?>
    <section class="login_reg">
        <a href="<?php if(class_exists( 'WPUF_Coupons' )) { echo wp_registration_url(); } else { echo get_permalink( get_option('woocommerce_myaccount_page_id') ); } ?>" title="<?php _e('注册一个新的帐户','salong'); ?>"><i class="icon-login"></i><?php _e('注册','salong'); ?></a>｜
        <a href="<?php echo wp_lostpassword_url(); ?>" title="<?php _e('忘记密码','salong'); ?>"><i class="icon-lock"></i><?php _e('忘记密码','salong'); ?></a>
    </section>
</section>